"""セキュリティ用語マップ 管理サーバー

- 用語と関係をSQLiteで管理し、REST APIで追加・変更・削除する
- 同じサーバーが public/ の静的ファイルも配信する
- 公開用の静的JSON(public/data/*.json)はエクスポートAPIで書き出す

起動:
    pip install -r server/requirements.txt
    python -m uvicorn server.app:app --host 0.0.0.0 --port 8080
"""
from __future__ import annotations

import json
import os
import re
import secrets
import sqlite3
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
PUBLIC = ROOT / "public"
DB_PATH = Path(os.environ.get("TERMMAP_DB", ROOT / "server" / "termmap.db"))
TOKEN_FILE = ROOT / "server" / ".admin-token"
ID_RE = re.compile(r"^[a-z0-9-]+$")


# ---------- DB ----------

def db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def init_db() -> None:
    with db() as con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS terms (
              id          TEXT PRIMARY KEY,
              label       TEXT NOT NULL,
              category    TEXT NOT NULL,
              description TEXT NOT NULL,
              refs        TEXT NOT NULL DEFAULT '[]',
              domain      TEXT NOT NULL DEFAULT 'core',
              updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS relations (
              id       INTEGER PRIMARY KEY AUTOINCREMENT,
              from_id  TEXT NOT NULL REFERENCES terms(id) ON DELETE CASCADE,
              to_id    TEXT NOT NULL REFERENCES terms(id) ON DELETE CASCADE,
              label    TEXT NOT NULL,
              UNIQUE(from_id, to_id)
            );
            CREATE TABLE IF NOT EXISTS meta (
              key   TEXT PRIMARY KEY,
              value TEXT NOT NULL
            );
            """
        )


def meta_get(con: sqlite3.Connection, key: str, default):
    row = con.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return json.loads(row["value"]) if row else default


def admin_token() -> str:
    token = os.environ.get("TERMMAP_TOKEN")
    if token:
        return token
    if TOKEN_FILE.exists():
        return TOKEN_FILE.read_text(encoding="utf-8").strip()
    token = secrets.token_urlsafe(24)
    TOKEN_FILE.write_text(token + "\n", encoding="utf-8")
    TOKEN_FILE.chmod(0o600)
    print(f"[termmap] 管理トークンを作成しました: {TOKEN_FILE}")
    return token


def require_token(x_api_key: Optional[str] = Header(default=None)) -> None:
    if not x_api_key or not secrets.compare_digest(x_api_key, admin_token()):
        raise HTTPException(status_code=401, detail="X-API-Key ヘッダーが必要です")


# ---------- モデル ----------

class Ref(BaseModel):
    title: str = ""
    url: str


class TermIn(BaseModel):
    id: str = Field(pattern=r"^[a-z0-9-]+$")
    label: str
    category: str
    description: str
    refs: list[Ref] = []
    domain: str = "core"


class TermPatch(BaseModel):
    label: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None
    refs: Optional[list[Ref]] = None
    domain: Optional[str] = None


class RelationIn(BaseModel):
    from_id: str = Field(alias="from")
    to_id: str = Field(alias="to")
    label: str

    model_config = {"populate_by_name": True}


app = FastAPI(title="セキュリティ用語マップ 管理API", version="1.0")
init_db()
admin_token()  # 起動時にトークンを用意する
print(f"[termmap] 管理トークンの保管先: {TOKEN_FILE}"
      if not os.environ.get("TERMMAP_TOKEN") else "[termmap] 管理トークンは環境変数 TERMMAP_TOKEN を使います")


def term_row(r: sqlite3.Row) -> dict:
    return {"id": r["id"], "label": r["label"], "category": r["category"],
            "description": r["description"], "refs": json.loads(r["refs"]), "domain": r["domain"]}


# ---------- 参照API(認証なし) ----------

@app.get("/api/graph")
def get_graph():
    with db() as con:
        terms = [term_row(r) for r in con.execute("SELECT * FROM terms ORDER BY id")]
        rels = [{"id": r["id"], "from": r["from_id"], "to": r["to_id"], "label": r["label"]}
                for r in con.execute("SELECT * FROM relations ORDER BY id")]
        return {"roots": meta_get(con, "roots", []), "categories": meta_get(con, "categories", []),
                "terms": terms, "relations": rels}


@app.get("/api/terms")
def list_terms(q: str = "", category: str = ""):
    sql, args = "SELECT * FROM terms WHERE 1=1", []
    if q:
        sql += " AND (label LIKE ? OR id LIKE ? OR description LIKE ?)"
        args += [f"%{q}%"] * 3
    if category:
        sql += " AND category = ?"
        args.append(category)
    with db() as con:
        return [term_row(r) for r in con.execute(sql + " ORDER BY id", args)]


@app.get("/api/terms/{term_id}")
def get_term(term_id: str):
    with db() as con:
        row = con.execute("SELECT * FROM terms WHERE id = ?", (term_id,)).fetchone()
        if not row:
            raise HTTPException(404, "その用語はありません")
        rels = [{"id": r["id"], "from": r["from_id"], "to": r["to_id"], "label": r["label"]}
                for r in con.execute("SELECT * FROM relations WHERE from_id = ? OR to_id = ?", (term_id, term_id))]
        return {**term_row(row), "relations": rels}


# ---------- 更新API(トークン必須) ----------

@app.post("/api/terms", status_code=201, dependencies=[Depends(require_token)])
def create_term(t: TermIn):
    with db() as con:
        if con.execute("SELECT 1 FROM terms WHERE id = ?", (t.id,)).fetchone():
            raise HTTPException(409, f"id「{t.id}」はすでにあります")
        con.execute(
            "INSERT INTO terms (id, label, category, description, refs, domain) VALUES (?,?,?,?,?,?)",
            (t.id, t.label, t.category, t.description, json.dumps([r.model_dump() for r in t.refs], ensure_ascii=False), t.domain),
        )
    return get_term(t.id)


@app.patch("/api/terms/{term_id}", dependencies=[Depends(require_token)])
def update_term(term_id: str, patch: TermPatch):
    fields = patch.model_dump(exclude_none=True)
    if not fields:
        raise HTTPException(400, "更新する項目がありません")
    if "refs" in fields:
        fields["refs"] = json.dumps(fields["refs"], ensure_ascii=False)
    sets = ", ".join(f"{k} = ?" for k in fields) + ", updated_at = datetime('now')"
    with db() as con:
        cur = con.execute(f"UPDATE terms SET {sets} WHERE id = ?", [*fields.values(), term_id])
        if cur.rowcount == 0:
            raise HTTPException(404, "その用語はありません")
    return get_term(term_id)


@app.delete("/api/terms/{term_id}", dependencies=[Depends(require_token)])
def delete_term(term_id: str):
    with db() as con:
        cur = con.execute("DELETE FROM terms WHERE id = ?", (term_id,))
        if cur.rowcount == 0:
            raise HTTPException(404, "その用語はありません")
    return {"deleted": term_id}


@app.post("/api/relations", status_code=201, dependencies=[Depends(require_token)])
def create_relation(rel: RelationIn):
    if rel.from_id == rel.to_id:
        raise HTTPException(400, "同じ用語同士はつなげません")
    with db() as con:
        for tid in (rel.from_id, rel.to_id):
            if not con.execute("SELECT 1 FROM terms WHERE id = ?", (tid,)).fetchone():
                raise HTTPException(400, f"用語「{tid}」がありません")
        dup = con.execute(
            "SELECT 1 FROM relations WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?)",
            (rel.from_id, rel.to_id, rel.to_id, rel.from_id)).fetchone()
        if dup:
            raise HTTPException(409, "その2語はすでにつながっています")
        cur = con.execute("INSERT INTO relations (from_id, to_id, label) VALUES (?,?,?)",
                          (rel.from_id, rel.to_id, rel.label))
        return {"id": cur.lastrowid, "from": rel.from_id, "to": rel.to_id, "label": rel.label}


@app.delete("/api/relations/{rel_id}", dependencies=[Depends(require_token)])
def delete_relation(rel_id: int):
    with db() as con:
        cur = con.execute("DELETE FROM relations WHERE id = ?", (rel_id,))
        if cur.rowcount == 0:
            raise HTTPException(404, "その関係はありません")
    return {"deleted": rel_id}


@app.post("/api/export", dependencies=[Depends(require_token)])
def export_static():
    """DBの内容を public/data/*.json に書き出す(Cloudflareへの公開用)"""
    graph = get_graph()
    by_domain: dict[str, dict] = {}
    for t in graph["terms"]:
        d = t.pop("domain") or "core"
        by_domain.setdefault(d, {"terms": [], "relations": []})["terms"].append(t)
    for r in graph["relations"]:
        r.pop("id", None)
        owner = next((t for d in by_domain.values() for t in d["terms"] if t["id"] == r["from"]), None)
        domain = next((d for d, v in by_domain.items() if owner in v["terms"]), "core") if owner else "core"
        by_domain.setdefault(domain, {"terms": [], "relations": []})["relations"].append(r)

    data_dir = PUBLIC / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for domain, content in by_domain.items():
        path = data_dir / f"{domain}.json"
        path.write_text(json.dumps(content, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        written.append(path.name)
    index = {"roots": graph["roots"], "categories": graph["categories"], "files": sorted(written)}
    (data_dir / "index.json").write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"written": ["index.json", *sorted(written)], "terms": len(graph["terms"]), "relations": len(graph["relations"])}


@app.exception_handler(HTTPException)
def http_error(_, exc: HTTPException):
    return JSONResponse({"error": exc.detail}, status_code=exc.status_code)


app.mount("/", StaticFiles(directory=PUBLIC, html=True), name="static")
