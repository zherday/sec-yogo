"""public/data/*.json の内容をSQLiteへ取り込む(初回セットアップ用)

    python server/import_json.py
既存の同じidは上書きされます。
"""
import json
from pathlib import Path

import sys
from pathlib import Path as _P
sys.path.insert(0, str(_P(__file__).resolve().parent))
from app import DB_PATH, PUBLIC, db, init_db  # noqa: E402

def main() -> None:
    init_db()
    index = json.loads((PUBLIC / "data" / "index.json").read_text(encoding="utf-8"))
    terms = relations = 0
    with db() as con:
        con.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('roots', ?)",
                    (json.dumps(index["roots"], ensure_ascii=False),))
        con.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('categories', ?)",
                    (json.dumps(index["categories"], ensure_ascii=False),))
        for file in index["files"]:
            domain = Path(file).stem
            part = json.loads((PUBLIC / "data" / file).read_text(encoding="utf-8"))
            for t in part.get("terms", []):
                con.execute(
                    "INSERT OR REPLACE INTO terms (id, label, category, description, refs, domain) VALUES (?,?,?,?,?,?)",
                    (t["id"], t["label"], t["category"], t["description"],
                     json.dumps(t.get("refs", []), ensure_ascii=False), domain))
                terms += 1
        for file in index["files"]:
            part = json.loads((PUBLIC / "data" / file).read_text(encoding="utf-8"))
            for r in part.get("relations", []):
                con.execute("INSERT OR IGNORE INTO relations (from_id, to_id, label) VALUES (?,?,?)",
                            (r["from"], r["to"], r["label"]))
                relations += 1
    print(f"取り込み完了: 用語 {terms} 件 / 関係 {relations} 件 → {DB_PATH}")

if __name__ == "__main__":
    import sys
    sys.path.insert(0, str(Path(__file__).parent))
    main()
