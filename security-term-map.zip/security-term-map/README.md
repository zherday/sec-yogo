# セキュリティ用語マップ

ネットワーク、セキュリティ、AD/Microsoft、Linuxの用語を、つながりから学べるインタラクティブな用語マップです。
丸(用語)をクリックすると関連用語が周りに広がり、横のパネルに説明が表示されます。

## フォルダ構成

```
security-term-map/
├── public/                   ← この中身がそのまま公開される
│   ├── index.html
│   ├── 404.html
│   ├── css/style.css         ← 色・レイアウト
│   ├── js/app.js             ← グラフの動き
│   ├── data/                 ← 用語データ(普段編集するのはここ)
│   │   ├── index.json        ← 最初に表示する用語・カテゴリ・読み込むファイル一覧
│   │   ├── core.json         ← ネットワーク / セキュリティの基礎
│   │   ├── identity.json     ← Active Directory・認証・AD狙いの攻撃
│   │   ├── microsoft.json    ← Windows / Microsoft製品
│   │   ├── linux.json        ← Linux
│   │   └── addressing.json   ← 特殊なIPアドレス帯・ポート範囲
│   └── vendor/               ← Cytoscape.js(MITライセンス)
├── scripts/validate.mjs      ← データのチェック
├── scripts/build-single.mjs  ← 1枚のHTMLにまとめる(配布・オフライン用)
├── .github/workflows/        ← push時に自動でデータをチェック
└── wrangler.jsonc            ← Cloudflare Workers用の設定
```

## ローカルで確認する

`index.html` を直接開くとデータを読み込めません。簡易サーバー経由で開いてください。

```bash
python3 -m http.server 8000 -d public
# ブラウザで http://localhost:8000
```

## 用語を追加する

該当する分野のJSONの `terms` に追加します(例:`public/data/linux.json`)。

```json
{
  "id": "nmap",
  "label": "Nmap",
  "category": "attack",
  "description": "ネットワーク上のホストや開いているポート、稼働サービスを調べるツール。調査にも攻撃の下調べにも使われる。",
  "refs": [{ "title": "Nmap 公式", "url": "https://nmap.org/" }]
}
```

同じファイルの `relations` につながりを足します。「from ─label→ to」と読める向きにします。

```json
{ "from": "nmap", "to": "portscan", "label": "使うツール" }
```

関係は**ファイルをまたいでもOK**です(`linux.json` の用語から `core.json` の用語へつないで構いません)。

最後にチェックします。

```bash
node scripts/validate.mjs
```

### 分野(ファイル)を増やす場合

1. `public/data/` に新しいJSON(`{"terms": [], "relations": []}`)を作る
2. `index.json` の `files` にファイル名を追加
3. 新しいカテゴリを使うなら `index.json` の `categories` に追加し、`css/style.css` の色変数(`--c-<カテゴリid>`)をライト・ダークの両方に追加

### 決めているルール

- `id` は半角英小文字・数字・ハイフン。一度決めたら変えない(関係の参照に使うため)
- 説明は3文以内。長くなったら用語を分ける合図
- 関係のラベルは増やしすぎない。既存の言い回しで表せないか先に考える
- 可能なら `refs` に一次情報(RFC、IPA、ベンダー公式)を付ける

## 社内の辞書として使う場合の注意

このリポジトリを公開する場合、**自社固有の情報は絶対に入れない**でください。
具体的には、社内のドメイン名、サーバー名、IPアドレス、監視ルールの中身、顧客名、製品の設定値などです。
一般的な用語の説明にとどめ、社内固有の内容を載せたい場合は次のどちらかにします。

- プライベートリポジトリを用意し、Cloudflare Access(Zero Trust)でアクセスを社内メンバーに限定する
- 社内固有の部分はSharePointなど既存の社内システムに置き、この用語マップからは切り離す

## 公開する(GitHub + Cloudflare)

### 1. GitHubにpushする

```bash
cd security-term-map
git init
git add .
git commit -m "初回コミット"
git branch -M main
git remote add origin https://github.com/<ユーザー名>/security-term-map.git
git push -u origin main
```

### 2A. Cloudflare Workers で公開する(Cloudflareが新規プロジェクトに推奨)

1. Cloudflareダッシュボード → Workers & Pages → 作成 → GitHubのリポジトリをインポート
2. GitHub連携を許可し、`security-term-map` を選ぶ
3. ビルドコマンドは空欄、デプロイコマンドは `npx wrangler deploy`
4. `https://security-term-map.<サブドメイン>.workers.dev` で確認

### 2B. Cloudflare Pages で公開する場合

1. Workers & Pages → 作成 → Pages → Gitに接続
2. フレームワーク:なし / ビルドコマンド:空欄 / 出力ディレクトリ:`public`

### 3. 以降の更新

`main` に push すると自動で反映されます。

## 1枚のHTMLとして配布する

社内で共有したいときや、オフラインで見たいときに使います。

```bash
node scripts/build-single.mjs
# dist/security-term-map.html ができる(これ1つで動く)
```

## ライセンス

- Cytoscape.js: MIT License(`public/vendor/cytoscape-LICENSE.txt`)

---

## 自宅のPC / ラズパイで管理サーバーとして動かす

`server/` にSQLite + REST APIの管理サーバーがあります。用語の追加・変更・削除をAPIや管理画面から行い、
公開用の静的JSON(`public/data/*.json`)を書き出す、という使い方を想定しています。

```
[ラズパイ] SQLite + API + 管理画面 ──書き出し──> public/data/*.json ──git push──> Cloudflare(公開)
```

### セットアップ

```bash
sudo apt update && sudo apt install -y python3-venv
cd ~/security-term-map
python3 -m venv .venv && . .venv/bin/activate
pip install -r server/requirements.txt
python server/import_json.py          # 既存のJSONをSQLiteへ取り込む(初回のみ)
python -m uvicorn server.app:app --host 0.0.0.0 --port 8080
```

- 用語マップ: `http://<ラズパイのIP>:8080/`
- 管理画面: `http://<ラズパイのIP>:8080/admin.html`
- APIドキュメント(自動生成): `http://<ラズパイのIP>:8080/docs`
- 管理トークン: 初回起動時に `server/.admin-token` が作られます。`TERMMAP_TOKEN` 環境変数でも指定できます

### API

参照は誰でも、更新は `X-API-Key` ヘッダーが必要です。

| メソッド | パス | 用途 |
| --- | --- | --- |
| GET | `/api/graph` | 画面が使う全データ(用語・関係・カテゴリ) |
| GET | `/api/terms?q=&category=` | 用語の検索 |
| GET | `/api/terms/{id}` | 1件取得(つながり付き) |
| POST | `/api/terms` | 追加 |
| PATCH | `/api/terms/{id}` | 変更(送った項目だけ更新) |
| DELETE | `/api/terms/{id}` | 削除(つながりも一緒に消える) |
| POST | `/api/relations` | つながりを追加 |
| DELETE | `/api/relations/{id}` | つながりを削除 |
| POST | `/api/export` | `public/data/*.json` を書き出す |

```bash
TOKEN=$(cat server/.admin-token)
curl -X POST http://localhost:8080/api/terms \
  -H "X-API-Key: $TOKEN" -H 'Content-Type: application/json' \
  -d '{"id":"nmap","label":"Nmap","category":"attack","domain":"core",
       "description":"ホストや開いているポート、稼働サービスを調べるツール。"}'

curl -X POST http://localhost:8080/api/relations \
  -H "X-API-Key: $TOKEN" -H 'Content-Type: application/json' \
  -d '{"from":"nmap","to":"portscan","label":"使うツール"}'
```

画面(`/`)は、APIが使えればAPIから、使えなければ `data/*.json` から読み込みます。
そのためCloudflare上の静的サイトでも同じファイルがそのまま動きます。

### 常駐させる

`server/termmap.service` を `/etc/systemd/system/termmap.service` にコピーし、ユーザー名とパスを直してから:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now termmap
journalctl -u termmap -f
```

### 公開サイトへの反映

管理画面の「公開用JSONを書き出す」またはAPIの `/api/export` を叩いたあと、gitでpushします。

```bash
curl -X POST http://localhost:8080/api/export -H "X-API-Key: $TOKEN"
node scripts/validate.mjs
git add public/data && git commit -m "用語を更新" && git push
```

### セキュリティ上の注意

- **このサーバーをインターネットに直接公開しない**でください。管理APIはトークン1つで守られているだけです
- 自宅の外から使いたい場合は、ポート開放ではなくVPN(WireGuardなど)やTailscale経由で接続する
- `server/.admin-token` と `server/termmap.db` はgitに入りません(`.gitignore` 済み)
- バックアップは `server/termmap.db` をコピーするだけです(`sqlite3 termmap.db .dump > backup.sql` でも可)
