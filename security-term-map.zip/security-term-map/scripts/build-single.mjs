// 1枚のHTMLにまとめる(共有・オフライン確認用): node scripts/build-single.mjs
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath, URL } from 'node:url';

const root = new URL('../public/', import.meta.url);
const read = p => readFileSync(new URL(p, root), 'utf8');
const index = JSON.parse(read('data/index.json'));
const data = {roots:index.roots, categories:index.categories, terms:[], relations:[]};
for (const f of index.files) {
  const part = JSON.parse(read('data/' + f));
  data.terms.push(...(part.terms || []));
  data.relations.push(...(part.relations || []));
}

let html = read('index.html');
let app = read('js/app.js').replace(
  /let DATA;[\s\S]*?\n}\n\n/,
  'const DATA = window.__TERM_DATA__;\n\n'
);

html = html
  .replace(/<link rel="stylesheet" href="css\/style.css">/, () => `<style>\n${read('css/style.css')}\n</style>`)
  .replace(/<script src="vendor\/cytoscape.min.js"><\/script>/, () => `<script>\n${read('vendor/cytoscape.min.js')}\n</script>`)
  .replace(/<script src="js\/app.js"><\/script>/, () => `<script>\nwindow.__TERM_DATA__ = ${JSON.stringify(data)};\n</script>\n<script>\n${app}\n</script>`);

mkdirSync(new URL('../dist/', import.meta.url), {recursive:true});
const out = fileURLToPath(new URL('../dist/security-term-map.html', import.meta.url));
writeFileSync(out, html);
console.log('作成:', out, Math.round(html.length / 1024) + 'KB');
