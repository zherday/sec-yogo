// 用語データのチェック: node scripts/validate.mjs
import { readFileSync } from 'node:fs';

const load = f => JSON.parse(readFileSync(new URL('../public/data/' + f, import.meta.url), 'utf8'));
const index = load('index.json');
const errors = [], warnings = [];
const catIds = new Set(index.categories.map(c => c.id));
const ids = new Map();   // id -> ファイル名
const relations = [];

for (const file of index.files) {
  const part = load(file);
  for (const t of part.terms || []) {
    if (!/^[a-z0-9-]+$/.test(t.id)) errors.push(`${file}: id「${t.id}」は半角英小文字・数字・ハイフンだけにしてください`);
    if (ids.has(t.id)) errors.push(`${file}: id「${t.id}」が ${ids.get(t.id)} と重複しています`);
    ids.set(t.id, file);
    if (!catIds.has(t.category)) errors.push(`${file}: 「${t.label}」のカテゴリ「${t.category}」が index.json にありません`);
    if (!t.label || !t.description) errors.push(`${file}: 「${t.id}」に label か description がありません`);
    for (const r of t.refs || []) if (!/^https:\/\//.test(r.url || '')) errors.push(`${file}: 「${t.label}」の参考URLは https:// で始めてください`);
  }
  for (const r of part.relations || []) relations.push({...r, file});
}

for (const r of index.roots) if (!ids.has(r)) errors.push(`index.json: roots の「${r}」が用語にありません`);

const pairs = new Set(), degree = {};
for (const r of relations) {
  if (!ids.has(r.from)) errors.push(`${r.file}: 関係の from「${r.from}」が用語にありません`);
  if (!ids.has(r.to)) errors.push(`${r.file}: 関係の to「${r.to}」が用語にありません`);
  if (r.from === r.to) errors.push(`${r.file}: 「${r.from}」が自分自身とつながっています`);
  const key = [r.from, r.to].sort().join('|');
  if (pairs.has(key)) warnings.push(`「${r.from}」と「${r.to}」の関係が重複しています`);
  pairs.add(key);
  degree[r.from] = (degree[r.from] || 0) + 1;
  degree[r.to] = (degree[r.to] || 0) + 1;
}
for (const id of ids.keys()) if (!degree[id]) warnings.push(`「${id}」はどの用語ともつながっていません`);

warnings.forEach(w => console.warn('注意:', w));
if (errors.length) { errors.forEach(e => console.error('エラー:', e)); process.exit(1); }
console.log(`OK: 用語 ${ids.size} 件 / 関係 ${relations.length} 件 / ファイル ${index.files.length} 個`);
