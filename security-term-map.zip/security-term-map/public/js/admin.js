// 用語マップ 管理画面(管理サーバー経由でのみ動作)
(function(){
const $ = s => document.querySelector(s);
const msg = (text, ok = true) => { const m = $('#msg'); m.textContent = text; m.className = 'msg ' + (ok ? 'ok' : 'ng'); };
const token = () => $('#token').value.trim();

let graph = {terms:[], relations:[], categories:[]};
let selected = null;

async function api(path, options = {}){
  const opt = {...options, headers:{'Content-Type':'application/json', ...(options.headers || {})}};
  if (options.method && options.method !== 'GET') opt.headers['X-API-Key'] = token();
  const res = await fetch(path, opt);
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || body.detail || ('HTTP ' + res.status));
  return body;
}

async function load(){
  try {
    graph = await api('api/graph');
    renderCategories();
    renderTerms();
    renderRelations();
    msg(`読み込みました(用語 ${graph.terms.length} 件 / 関係 ${graph.relations.length} 件)`);
  } catch (e) { msg('読み込みに失敗しました: ' + e.message, false); }
}

function renderCategories(){
  $('#f-cat').replaceChildren(...graph.categories.map(c => {
    const o = document.createElement('option'); o.value = c.id; o.textContent = `${c.name}(${c.id})`; return o;
  }));
  const domains = [...new Set(graph.terms.map(t => t.domain || 'core'))].sort();
  $('#domains').replaceChildren(...domains.map(d => { const o = document.createElement('option'); o.value = d; return o; }));
  $('#allterms').replaceChildren(...graph.terms.map(t => {
    const o = document.createElement('option'); o.value = t.id; o.textContent = t.label; return o;
  }));
}

function renderTerms(){
  const q = $('#filter').value.trim().toLowerCase();
  const hits = graph.terms.filter(t => !q || (t.label + t.id + t.description).toLowerCase().includes(q));
  $('#termlist').replaceChildren(...hits.slice(0, 200).map(t => {
    const li = document.createElement('li');
    const span = document.createElement('span'); span.className = 'grow';
    span.innerHTML = '';
    span.append(t.label, ' ');
    const small = document.createElement('small'); small.textContent = `${t.id} / ${t.category} / ${t.domain || 'core'}`;
    span.append(small);
    const btn = document.createElement('button'); btn.className = 'btn'; btn.type = 'button'; btn.textContent = '編集';
    btn.addEventListener('click', () => select(t.id));
    li.append(span, btn);
    return li;
  }));
  if (!hits.length) $('#termlist').textContent = '該当する用語がありません';
}

function select(id){
  const t = graph.terms.find(x => x.id === id);
  if (!t) return;
  selected = id;
  $('#formlegend').textContent = `編集中: ${t.label}`;
  $('#f-id').value = t.id; $('#f-id').disabled = true;
  $('#f-label').value = t.label;
  $('#f-cat').value = t.category;
  $('#f-domain').value = t.domain || 'core';
  $('#f-desc').value = t.description;
  $('#f-refs').value = (t.refs || []).map(r => `${r.title || ''}|${r.url}`).join('\n');
  renderRelations();
  window.scrollTo({top: $('#formlegend').getBoundingClientRect().top + window.scrollY - 20, behavior:'smooth'});
}

function clearForm(){
  selected = null;
  $('#formlegend').textContent = '新規追加';
  ['#f-id','#f-label','#f-desc','#f-refs'].forEach(s => $(s).value = '');
  $('#f-id').disabled = false;
  $('#f-domain').value = 'core';
  renderRelations();
}

function parseRefs(){
  return $('#f-refs').value.split('\n').map(l => l.trim()).filter(Boolean).map(line => {
    const [title, url] = line.split('|').map(s => (s || '').trim());
    return url ? {title, url} : {title:'', url:title};
  });
}

async function save(){
  const body = {
    id: $('#f-id').value.trim(), label: $('#f-label').value.trim(), category: $('#f-cat').value,
    description: $('#f-desc').value.trim(), refs: parseRefs(), domain: $('#f-domain').value.trim() || 'core'
  };
  if (!body.id || !body.label || !body.description) { msg('id・表示名・説明は必須です', false); return; }
  try {
    if (selected) {
      const {id, ...patch} = body;
      await api('api/terms/' + selected, {method:'PATCH', body: JSON.stringify(patch)});
      msg(`「${body.label}」を更新しました`);
    } else {
      await api('api/terms', {method:'POST', body: JSON.stringify(body)});
      msg(`「${body.label}」を追加しました`);
      selected = body.id; $('#f-id').disabled = true; $('#formlegend').textContent = `編集中: ${body.label}`;
    }
    await load(); if (selected) select(selected);
  } catch (e) { msg('保存に失敗しました: ' + e.message, false); }
}

async function removeTerm(){
  if (!selected) { msg('削除する用語が選ばれていません', false); return; }
  const t = graph.terms.find(x => x.id === selected);
  if (!confirm(`「${t.label}」と、そのつながりをすべて削除します。よろしいですか?`)) return;
  try {
    await api('api/terms/' + selected, {method:'DELETE'});
    msg(`「${t.label}」を削除しました`);
    clearForm(); await load();
  } catch (e) { msg('削除に失敗しました: ' + e.message, false); }
}

function renderRelations(){
  const ul = $('#rellist');
  if (!selected) { ul.textContent = '用語を選ぶと、そのつながりが表示されます'; return; }
  const label = id => (graph.terms.find(t => t.id === id) || {}).label || id;
  const rels = graph.relations.filter(r => r.from === selected || r.to === selected);
  ul.replaceChildren(...rels.map(r => {
    const li = document.createElement('li');
    const span = document.createElement('span'); span.className = 'grow';
    span.textContent = `${label(r.from)} ─${r.label}→ ${label(r.to)}`;
    const btn = document.createElement('button'); btn.className = 'btn danger'; btn.type = 'button'; btn.textContent = '削除';
    btn.addEventListener('click', async () => {
      try { await api('api/relations/' + r.id, {method:'DELETE'}); msg('つながりを削除しました'); await load(); select(selected); }
      catch (e) { msg('削除に失敗しました: ' + e.message, false); }
    });
    li.append(span, btn);
    return li;
  }));
  if (!rels.length) ul.textContent = 'つながりはまだありません';
}

async function addRelation(){
  if (!selected) { msg('先に用語を選んでください', false); return; }
  const input = $('#r-other').value.trim();
  const other = graph.terms.find(t => t.id === input || t.label === input);
  const relLabel = $('#r-label').value.trim();
  if (!other) { msg('相手の用語が見つかりません', false); return; }
  if (!relLabel) { msg('関係のラベルを入力してください', false); return; }
  const body = $('#r-dir').value === 'out'
    ? {from: selected, to: other.id, label: relLabel}
    : {from: other.id, to: selected, label: relLabel};
  try {
    await api('api/relations', {method:'POST', body: JSON.stringify(body)});
    msg('つながりを追加しました');
    $('#r-other').value = ''; $('#r-label').value = '';
    await load(); select(selected);
  } catch (e) { msg('追加に失敗しました: ' + e.message, false); }
}

$('#load').addEventListener('click', load);
$('#filter').addEventListener('input', renderTerms);
$('#save').addEventListener('click', save);
$('#new').addEventListener('click', clearForm);
$('#delete').addEventListener('click', removeTerm);
$('#addrel').addEventListener('click', addRelation);
$('#export').addEventListener('click', async () => {
  try { const r = await api('api/export', {method:'POST'}); msg(`書き出しました: ${r.written.join(', ')}(用語 ${r.terms} 件)`); }
  catch (e) { msg('書き出しに失敗しました: ' + e.message, false); }
});

clearForm();
load();
})();
