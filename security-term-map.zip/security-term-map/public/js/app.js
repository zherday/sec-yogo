// セキュリティ用語マップ
// 用語データは public/data/ のJSONに分離しています(data/index.json が一覧)。
(async function(){
const $ = s => document.querySelector(s);
const fetchJson = async path => {
  const res = await fetch(path, {cache:'no-cache'});
  if (!res.ok) throw new Error(path + ': HTTP ' + res.status);
  return res.json();
};

let DATA;
try {
  // 管理サーバー(server/app.py)経由で開いている場合はAPIから取得する
  DATA = await fetchJson('api/graph');
} catch (apiErr) {
  try {
    const index = await fetchJson('data/index.json');
    const parts = await Promise.all(index.files.map(f => fetchJson('data/' + f)));
    DATA = {roots:index.roots, categories:index.categories, terms:[], relations:[]};
    parts.forEach((p, i) => {
      (p.terms || []).forEach(t => {
        if (DATA.terms.some(x => x.id === t.id)) console.warn('idが重複しています:', t.id, '(' + index.files[i] + ')');
        DATA.terms.push(t);
      });
      DATA.relations.push(...(p.relations || []));
    });
  } catch (err) {
    $('#cy').textContent = '用語データを読み込めませんでした。ローカルで確認する場合は、ファイルを直接開かずに簡易サーバー経由で開いてください。';
    $('#cy').classList.add('load-error');
    console.error(err);
    return;
  }
}

const CATS = {}; DATA.categories.forEach(c => CATS[c.id] = {name:c.name});
const ROOTS = DATA.roots;
const T = {}; DATA.terms.forEach(t => T[t.id] = {id:t.id, label:t.label, cat:t.category, desc:t.description, refs:t.refs || []});
const EDGES = DATA.relations.map(r => [r.from, r.to, r.label]);
const ADJ = {}; Object.keys(T).forEach(id => ADJ[id] = []);
EDGES.forEach(([s,t,l],i) => {
  if (!T[s] || !T[t]) { console.warn('存在しない用語を参照している関係:', s, t); return; }
  ADJ[s].push({other:t, label:l, dir:'out', eid:'e'+i});
  ADJ[t].push({other:s, label:l, dir:'in', eid:'e'+i});
});

const panel = $('#panel'), statusEl = $('#status');
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const mobileMQ = matchMedia('(max-width: 759px)');
const cssVar = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const catColor = c => cssVar('--c-' + c);
let current = null;

if (typeof cytoscape === 'undefined') {
  $('#cy').textContent = 'グラフ描画用のライブラリを読み込めませんでした。ネットワーク接続を確認して、ページを再読み込みしてください。';
  return;
}

function buildStyle(){
  const text = cssVar('--text'), muted = cssVar('--muted'), line = cssVar('--line'), bg = cssVar('--graph');
  const font = 'IBM Plex Sans JP, Hiragino Sans, Yu Gothic UI, Noto Sans JP, sans-serif';
  const s = [
    {selector:'node', style:{
      'width':30, 'height':30, 'border-width':0, 'label':'data(label)', 'font-family':font, 'font-size':11,
      'color':text, 'text-valign':'bottom', 'text-margin-y':6, 'text-wrap':'wrap', 'text-max-width':120,
      'text-outline-color':bg, 'text-outline-width':3, 'transition-property':'opacity', 'transition-duration':'0.2s'
    }},
    {selector:'node[root = 1]', style:{'width':46, 'height':46, 'font-size':13, 'font-weight':600}},
    {selector:'node.more', style:{'border-width':2, 'border-style':'dashed', 'border-color':text}},
    {selector:'node.focus', style:{'border-width':4, 'border-style':'solid', 'border-color':text, 'font-weight':600, 'font-size':13}},
    {selector:'edge', style:{
      'width':1.2, 'line-color':line, 'target-arrow-color':line, 'target-arrow-shape':'triangle', 'arrow-scale':0.8,
      'curve-style':'bezier', 'font-family':font
    }},
    {selector:'edge.hl', style:{
      'width':2, 'line-color':muted, 'target-arrow-color':muted, 'label':'data(label)', 'font-size':10, 'color':text,
      'text-background-color':bg, 'text-background-opacity':0.9, 'text-background-padding':2, 'text-rotation':'autorotate'
    }},
    {selector:'.faded', style:{'opacity':0.22}}
  ];
  Object.keys(CATS).forEach(k => s.splice(1, 0, {selector:`node[cat = "${k}"]`, style:{'background-color':catColor(k)}}));
  return s;
}

const cy = cytoscape({
  container: $('#cy'), style: buildStyle(), minZoom:0.25, maxZoom:2.5, boxSelectionEnabled:false
});

const visible = id => cy.getElementById(id).length > 0;

function addNode(id, pos){
  if (visible(id)) return false;
  cy.add({group:'nodes', data:{id, label:T[id].label, cat:T[id].cat, root: ROOTS.includes(id) ? 1 : 0}, position: pos || {x:0, y:0}});
  return true;
}
function syncEdges(){
  EDGES.forEach(([s,t,l],i) => {
    if (T[s] && T[t] && visible(s) && visible(t) && !visible('e'+i)) cy.add({group:'edges', data:{id:'e'+i, source:s, target:t, label:l}});
  });
}
function markMore(){
  cy.nodes().forEach(n => n.toggleClass('more', ADJ[n.id()].some(a => !visible(a.other))));
}
function expand(id){
  const n = cy.getElementById(id), p = n.position();
  const newIds = [...new Set(ADJ[id].map(a => a.other))].filter(o => !visible(o));
  if (!newIds.length) return false;
  const others = cy.nodes().not(n);
  let base = 0, spread;
  if (others.length){
    const bb = others.boundingBox();
    base = Math.atan2(p.y - (bb.y1 + bb.y2) / 2, p.x - (bb.x1 + bb.x2) / 2);
    spread = Math.min(Math.PI * 1.5, (newIds.length - 1) * 0.6);
  } else {
    spread = Math.PI * 2 * (newIds.length - 1) / newIds.length;
  }
  newIds.forEach((o, i) => {
    const a = newIds.length === 1 ? base : base - spread / 2 + spread * i / (newIds.length - 1);
    addNode(o, {x: p.x + 140 * Math.cos(a), y: p.y + 140 * Math.sin(a)});
  });
  syncEdges(); markMore();
  return true;
}

let running = null;
function runLayout(opts, done){
  opts = opts || {};
  if (running) running.stop();
  const anchor = opts.anchor ? cy.getElementById(opts.anchor) : null;
  if (anchor) anchor.lock();
  const l = cy.layout({
    name:'cose', randomize:!!opts.randomize, animate: reduce ? false : 'end', animationDuration:450,
    fit:!!opts.fit, padding:50, nodeDimensionsIncludeLabels:true,
    nodeRepulsion:() => 14000, idealEdgeLength:() => 90, edgeElasticity:() => 90,
    nodeOverlap:30, gravity:0.5, numIter:1500, componentSpacing:90
  });
  l.one('layoutstop', () => { if (anchor) anchor.unlock(); running = null; if (done) done(); });
  running = l; l.run();
}

function panTo(id){
  const n = cy.getElementById(id); if (!n.length) return;
  const w = cy.width(), h = cy.height();
  const z = Math.max(cy.zoom(), 0.8);
  const ty = mobileMQ.matches ? h * 0.27 : h / 2;
  const p = n.position();
  const target = {zoom:z, pan:{x: w / 2 - p.x * z, y: ty - p.y * z}};
  if (reduce) cy.viewport(target); else cy.animate(target, {duration:350});
}

function highlight(id){
  cy.elements().removeClass('focus hl faded');
  if (!id) return;
  const n = cy.getElementById(id);
  cy.elements().not(n.closedNeighborhood()).addClass('faded');
  n.addClass('focus'); n.connectedEdges().addClass('hl');
}

function focusTerm(id){
  if (!T[id]) return;
  let changed = false;
  if (!visible(id)){
    const nb = ADJ[id].map(a => cy.getElementById(a.other)).find(x => x.length);
    let pos;
    if (nb) pos = {x: nb.position().x + 120, y: nb.position().y + 60};
    else { const e = cy.extent(); pos = {x:(e.x1 + e.x2) / 2, y:(e.y1 + e.y2) / 2}; }
    addNode(id, pos); syncEdges(); markMore(); changed = true;
  }
  if (expand(id)) changed = true;
  current = id;
  highlight(id);
  renderPanel(id);
  if (changed) runLayout({anchor:id}, () => panTo(id)); else panTo(id);
}

function clearFocus(){
  current = null; highlight(null); renderEmpty();
}

function el(tag, attrs, children){
  const e = document.createElement(tag);
  if (attrs) Object.entries(attrs).forEach(([k, v]) => { if (k === 'text') e.textContent = v; else if (k === 'style') e.style.cssText = v; else e.setAttribute(k, v); });
  (children || []).forEach(c => e.appendChild(c));
  return e;
}

function renderEmpty(){
  panel.classList.remove('open');
  panel.replaceChildren(el('div', {class:'empty'}, [
    el('p', {text:'丸をクリックすると、その用語の説明と、つながっている用語がここに表示されます。'}),
    el('p', {text:'点線で囲まれた丸には、まだ表示していない関連用語があります。クリックすると周りに広がります。'})
  ]));
}

function renderPanel(id){
  const t = T[id];
  const closeBtn = el('button', {class:'btn close', type:'button', text:'閉じる'});
  closeBtn.addEventListener('click', clearFocus);
  const rels = ADJ[id].slice().sort((a, b) => (a.dir === b.dir ? 0 : a.dir === 'out' ? -1 : 1));
  const list = el('ul', {class:'rel'}, rels.map(r => {
    const o = T[r.other];
    const sentence = r.dir === 'out' ? `${t.label} ─${r.label}→ ${o.label}` : `${o.label} ─${r.label}→ ${t.label}`;
    const b = el('button', {type:'button'}, [
      el('i', {style:'background:' + catColor(o.cat)}),
      el('strong', {text:o.label}),
      el('small', {text:sentence})
    ]);
    b.addEventListener('click', () => focusTerm(o.id));
    return el('li', null, [b]);
  }));
  panel.replaceChildren(
    closeBtn,
    el('span', {class:'chip'}, [el('i', {style:'background:' + catColor(t.cat)}), document.createTextNode(CATS[t.cat].name)]),
    el('h2', {text:t.label}),
    el('p', {class:'desc', text:t.desc}),
    el('h3', {text:`つながっている用語(${rels.length})`}),
    list
  );
  if (t.refs.length){
    panel.appendChild(el('h3', {class:'refs-title', text:'参考資料'}));
    panel.appendChild(el('ul', {class:'refs'}, t.refs.map(r => {
      const a = el('a', {href:r.url, target:'_blank', rel:'noopener noreferrer', text:r.title || r.url});
      return el('li', null, [a]);
    })));
  }
  panel.scrollTop = 0;
  panel.classList.add('open');
}

function renderLegend(){
  const lg = $('#legend');
  const items = Object.keys(CATS).map(k => el('span', null, [el('i', {style:'background:' + catColor(k)}), document.createTextNode(CATS[k].name)]));
  items.push(el('span', {class:'more-key'}, [el('i'), document.createTextNode('続きあり')]));
  lg.replaceChildren(...items);
}

function init(){
  cy.elements().remove();
  ROOTS.forEach((r, i) => addNode(r, {x:(i - (ROOTS.length - 1) / 2) * 360, y:0}));
  syncEdges();
  // 最初の画面が混みすぎない場合だけ、ルートの用語を開いた状態で始める
  const planned = new Set();
  ROOTS.forEach(r => ADJ[r].forEach(a => planned.add(a.other)));
  if (planned.size <= 20) ROOTS.forEach(expand);
  markMore();
  runLayout({randomize:true, fit:true});
}

function expandAll(){
  Object.keys(T).forEach(id => addNode(id, {x: Math.random() * 600, y: Math.random() * 600}));
  syncEdges(); markMore();
  if (current) highlight(current);
  runLayout({randomize:true, fit:true});
}

// 検索
const dl = $('#terms');
Object.values(T).forEach(t => dl.appendChild(el('option', {value:t.label})));
const q = $('#q');
function doSearch(){
  const v = q.value.trim().toLowerCase();
  statusEl.textContent = '';
  if (!v) return;
  const list = Object.values(T);
  const hit = list.find(t => t.label.toLowerCase() === v) || list.find(t => t.label.toLowerCase().includes(v));
  if (hit){ focusTerm(hit.id); q.blur(); }
  else statusEl.textContent = `「${q.value.trim()}」に一致する用語はありません。別の言葉で検索してください。`;
}
q.addEventListener('change', doSearch);
q.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); doSearch(); } });

$('#all').addEventListener('click', expandAll);
$('#fit').addEventListener('click', () => cy.animate({fit:{eles:cy.elements(), padding:40}}, {duration: reduce ? 0 : 350}));
$('#reset').addEventListener('click', () => { clearFocus(); statusEl.textContent = ''; q.value = ''; init(); });

cy.on('tap', 'node', e => focusTerm(e.target.id()));
cy.on('tap', e => { if (e.target === cy) clearFocus(); });

function refreshTheme(){ cy.style(buildStyle()); renderLegend(); if (current) renderPanel(current); }
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', refreshTheme);
new MutationObserver(refreshTheme).observe(document.documentElement, {attributes:true, attributeFilter:['data-theme']});
if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => cy.style().update());

renderLegend(); renderEmpty(); init();
})();
